#include <string>
#include <fstream>
#include <iostream>
using namespace std;
typedef char ItemType;
struct TreeNode
{
  ItemType info;
  TreeNode* left;
  TreeNode* right;
};
enum OrderType {PRE_ORDER, IN_ORDER, POST_ORDER};
class TreeType
{
public:
  TreeType();
 ~TreeType();
  TreeType(const TreeType& originalTree); 
  void operator=(const TreeType& originalTree);
    
public:
  void MakeEmpty();
  bool IsEmpty() const;
  bool IsFull() const;
  int LengthIs() const; 
  void RetrieveItem(ItemType& item, bool& found);
  void InsertItem(ItemType item);
  void ResetTree(OrderType order); 
  void GetNextItem (ItemType& item, OrderType order, bool& finished);
  void Print() const;
    
public:
  void DeleteSubtreeRootedWith(ItemType item); // Problem 2
  int LeafCount();
  int DiffLeaf(ItemType item);
 
private:
  TreeNode* root;
};

int CountLeafNodes(TreeNode* root); // Problem 1
int DiffLeafNodes(TreeNode* root, ItemType item); // Problem 3
void DeleteNode(TreeNode*& tree);
void Delete(TreeNode*& tree, ItemType item);


