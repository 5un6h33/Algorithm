#include "TreeType.h"

int main() {
	TreeType tree1;
	tree1.InsertItem('k');
	tree1.InsertItem('d');
	tree1.InsertItem('o');
	tree1.InsertItem('a');
	tree1.InsertItem('f');
	tree1.InsertItem('x');
	tree1.InsertItem('z');
    TreeType tree2(tree1);
    TreeType tree3(tree1);
    TreeType tree4(tree2);
    
    // Problem 1
	cout << "P1, tree1        : " << tree1.LeafCount() << endl;
    cout << "P1, tree2        : " << tree2.LeafCount() << endl << endl;
    
    // Problem 2
    tree1.DeleteSubtreeRootedWith('o');
    tree2.DeleteSubtreeRootedWith('d');
    cout << "P2, tree1        : " << tree1.LeafCount() << endl;
    cout << "P2, tree2        : " << tree2.LeafCount() << endl << endl;;
    
    // Problem 3
    cout << "P3, tree1 Diff   : " << tree3.DiffLeaf('o') << endl;
    cout << "P3, tree1 origin : " << tree3.LeafCount() << endl;
    cout << "P3, tree2 Diff   : " << tree4.DiffLeaf('d') << endl;
    cout << "P3, tree2 origin : " << tree4.LeafCount() << endl;
    
	return 0;
}
