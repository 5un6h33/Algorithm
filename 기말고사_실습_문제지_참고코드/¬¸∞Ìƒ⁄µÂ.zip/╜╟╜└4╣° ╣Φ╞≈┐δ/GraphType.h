#pragma once
#include "QueType.h"
#include "StackType.h"
#include <iostream>
template<class VertexType>
class GraphType
{
public:
  GraphType();                  // Default of 50 vertices
  GraphType(int maxV);          // maxV <= 50
  ~GraphType();
  void AddVertex(VertexType);
  void AddEdge(VertexType, VertexType, int);
  int WeightIs(VertexType, VertexType);
  void GetToVertices(VertexType, QueType<VertexType>&);
  void DepthFirstSearch(VertexType, VertexType);
  void ClearMarks();
  void MarkVertex(VertexType);
  bool IsMarked(VertexType);
    
public:
  void DFSforCircuit(VertexType); // TODO2
  bool IsCircuit(); // TODO1
    
private:
  int numVertices;
  int maxVertices;
  VertexType* vertices;
  int edges[50][50];
  bool* marks;	// marks[i] is mark for vertices[i].
  bool** edge_marks; // edge_marks[i][j] is mark for edge[i][j] 
};

template<class VertexType>
GraphType<VertexType>::GraphType()
// Post: Arrays of size 50 are dynamically allocated for  
//       marks and vertices.  numVertices is set to 0; 
//       maxVertices is set to 50.
{
    numVertices = 0;
    maxVertices = 50;
    vertices = new VertexType[50];
    for(int i = 0; i < 50; i ++){
        for(int j = 0; j < 50; j ++){
            edges[i][j] = 0;
        }
    }
    marks = new bool[50];
}

template<class VertexType>
GraphType<VertexType>::GraphType(int maxV)
// Post: Arrays of size maxV are dynamically allocated for  
//       marks and vertices.  
//       numVertices is set to 0; maxVertices is set to maxV.
{
    numVertices = 0;
    maxVertices = maxV;
    vertices = new VertexType[maxV];
    for(int i = 0; i < 50; i ++){
        for(int j = 0; j < 50; j ++){
            edges[i][j] = 0;
        }
    }
    marks = new bool[maxV];
}

template<class VertexType>
// Post: arrays for vertices and marks have been deallocated.
GraphType<VertexType>::~GraphType()
{
    delete[] vertices;
    delete[] marks;
}
const int NULL_EDGE = 0;

template<class VertexType>
void GraphType<VertexType>::AddVertex(VertexType vertex)
// Post: vertex has been stored in vertices.
//       Corresponding row and column of edges has been set 
//       to NULL_EDGE.
//       numVertices has been incremented.
{
    vertices[numVertices] = vertex;

    for (int index = 0; index < numVertices; index++)
    {
        edges[numVertices][index] = NULL_EDGE;
        edges[index][numVertices] = NULL_EDGE;
    }
    numVertices++;
}
template<class VertexType>
int IndexIs(VertexType* vertices, VertexType vertex)
// Post: Returns the index of vertex in vertices.
{
    int index = 0;

    while (!(vertex == vertices[index]))
        index++;
    return index;
}

template<class VertexType>
void GraphType<VertexType>::AddEdge(VertexType fromVertex,
    VertexType toVertex, int weight)
    // Post: Edge (fromVertex, toVertex) is stored in edges.
{
    int row;
    int col;

    row = IndexIs(vertices, fromVertex);
    col = IndexIs(vertices, toVertex);
    edges[row][col] = weight;
}

template<class VertexType>
int GraphType<VertexType>::WeightIs
(VertexType fromVertex, VertexType toVertex)
// Post: Returns the weight associated with the edge 
//       (fromVertex, toVertex).
{
    int row;
    int col;

    row = IndexIs(vertices, fromVertex);
    col = IndexIs(vertices, toVertex);
    return edges[row][col];
}
template<class VertexType>
void GraphType<VertexType>::GetToVertices(VertexType vertex,
    QueType<VertexType>& adjVertices)
    // Post: 
{
    int fromIndex;
    int toIndex;

    fromIndex = IndexIs(vertices, vertex);
    for (toIndex = 0; toIndex < numVertices; toIndex++)
        if (edges[fromIndex][toIndex] != NULL_EDGE)
            adjVertices.Enqueue(vertices[toIndex]);
}
template<class VertexType>
void GraphType<VertexType>::ClearMarks() {
    marks = new bool[maxVertices];
}
template<class VertexType>
void GraphType<VertexType>::MarkVertex(VertexType item) {
    int index = IndexIs(vertices, item);
    marks[index] = true;

}

template<class VertexType>
bool GraphType<VertexType>::IsMarked(VertexType item) {
    int index = IndexIs(vertices, item);
    if (marks[index] == true)
        return true;
    else
        return false;
}


template<class VertexType>
void GraphType<VertexType>::DepthFirstSearch(VertexType startVertex, VertexType endVertex)
{
    using namespace std;

    StackType<VertexType> stack;
    QueType<VertexType> vertexQ;
    bool found = false;
    VertexType vertex="";
    VertexType item;

    ClearMarks();
    stack.Push(startVertex);

    do
    {
        vertex = stack.Pop();
        if (vertex == endVertex)
        {
            cout << vertex << ' ';
            found = true;
        }
        else
        {
            if (!IsMarked(vertex))
            {
                MarkVertex(vertex);
                cout << vertex << ' ';
                GetToVertices(vertex, vertexQ);

                while (!vertexQ.IsEmpty())
                {
                    vertexQ.Dequeue(item);
                    if (!IsMarked(item))
                        stack.Push(item);
                }
            }
        }
    } while (!stack.IsEmpty() && !found);
    if (!found)
        cout << "Path not found." << endl;
}

template<class VertexType>
bool GraphType<VertexType>::IsCircuit() {
    bool is_circuit = true;
    int deg[50] = {0,}; // 현재 이 vertex가 몇개의 edge를 가지는지 저장하는 변수
    int n = numVertices; // vertex의 개수
    // TODO 1: 모든 vertex에서 edge가 짝수개인지 검사
    // Input your code
    return is_circuit;
}

template<class VertexType>
void GraphType<VertexType>::DFSforCircuit(VertexType startvertex) {
    // TODO 2: 실습 DFS를 구현한 코드를 참조하여 구현
    // 조건1, 한번 지나간 간선은 다시 지나가지 못함
    // 여기서 경로를 출력
    // Input your code
}
