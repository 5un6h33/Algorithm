#include <iostream>
#include "GraphType.h"
using namespace std;

int main() {

   GraphType<const char *> graph1;

   graph1.AddVertex("1");
   graph1.AddVertex("2");
   graph1.AddVertex("3");
   graph1.AddVertex("4");
   graph1.AddVertex("5");

   graph1.AddEdge("1", "3", 1);
   graph1.AddEdge("3", "1", 1);
   graph1.AddEdge("1", "4", 1);
   graph1.AddEdge("4", "1", 1);
   graph1.AddEdge("2", "4", 1);
   graph1.AddEdge("4", "2", 1);
   graph1.AddEdge("2", "5", 1);
   graph1.AddEdge("5", "2", 1);
   graph1.AddEdge("5", "3", 1);
   graph1.AddEdge("3", "5", 1);



   if(graph1.IsCircuit())
   {
      graph1.DFSforCircuit("1");
      cout << endl;
   }
   else
      cout << "Not Euler Circuit" << endl;

   GraphType<const char*> graph2;
   graph2.AddVertex("1");
   graph2.AddVertex("2");
   graph2.AddVertex("3");
   graph2.AddVertex("4");
   graph2.AddVertex("5");

   graph2.AddEdge("1", "2", 1);
   graph2.AddEdge("2", "1", 1);
   graph2.AddEdge("1", "3", 1);
   graph2.AddEdge("3", "1", 1);
   graph2.AddEdge("2", "3", 1);
   graph2.AddEdge("3", "2", 1);
   graph2.AddEdge("2", "4", 1);
   graph2.AddEdge("4", "2", 1);
   graph2.AddEdge("3", "5", 1);
   graph2.AddEdge("5", "3", 1);
   graph2.AddEdge("4", "5", 1);
   graph2.AddEdge("5", "4", 1);

   if (graph2.IsCircuit())
   {
      graph2.DFSforCircuit("1");
      cout << endl;
   }
   else
      cout << "Not Euler Circuit" << endl;
   return 0;
}
