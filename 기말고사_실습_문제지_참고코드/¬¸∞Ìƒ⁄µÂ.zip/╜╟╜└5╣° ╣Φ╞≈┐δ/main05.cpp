#include "YourClass.h"
#include <iostream>
using namespace std;

int main() {
    YourClass<int> model;
    
    // Input
    int k; cin >> k;
    int num;
    
    for(int i = 0; i < k; i ++){
        cin >> num;
        model.InsertItem(num);
    }
    
	// Solve
    model.Solve();
    	
	return 0;

}
